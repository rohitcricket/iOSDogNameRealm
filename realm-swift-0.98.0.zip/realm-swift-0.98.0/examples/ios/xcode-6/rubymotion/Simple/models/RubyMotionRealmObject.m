#import "RubyMotionRealmObject.h"

@implementation StringObject
@end

@implementation RubyMotionRealmObject
@end
